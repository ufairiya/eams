<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>

/*$html = '
           <h1><a name="top"></a>Energy Calculation</h1>
           <h2>Basic HTML Example</h2>
           <table border="1" style="width:102px;" class="circuit_name">
           <thead>
           <tr><th>&nbsp;</th></tr>    
           </thead>
           <tbody>';
foreach($Circuitname as $CircuitnameResult) 
 {
 $html.=    '<tr>
             <td>'.$CircuitnameResult.'</td>          
             </tr>';    
 }
$html.='
           <tr><td class="circuit_total">Total</td>
           </tbody>
           </table>
           <img src="http://localhost/energy1/generated/demo3.png"/>
		   <img src="http://localhost/energy1/generated/demo4.png"/>';*/
</body>
</html>