<?php
 //PDFList.php
 include_once 'ApplicationHeader.php';

?>

<a href="PDF/<?php echo $_SESSION['stockreport'];?>" target="_blank">Download Report</a>

<br>
<br>
<br>
<br>
<a href="StockReport.php"> &lt; &lt; Go back to Stock Report page.</a>
<br>
<br>
<br>
<br>
<a href="Reports.php"> &lt; &lt; Go back to Report List Page.</a>
